Calculates free disk space percentage of Windows drives.  
Runs every 60 seconds by default.