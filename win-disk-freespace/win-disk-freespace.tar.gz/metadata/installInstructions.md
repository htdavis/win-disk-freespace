## Installing Windows Disk Free Percent Extension
### Bundled with Infrastructure Agent (Using ACC)
- Create your agent package
- Include this extension under the Custom bundles
- Save your package and download using the provided link
- Copy the archive to your server and unzip
- Install the agent per documentation instructions
### Manual installation (downloaded from GitHub or ACC)
- Download archive
- Copy to <agent_home>\extensions\deploy
- Restart the agent to enable the extension